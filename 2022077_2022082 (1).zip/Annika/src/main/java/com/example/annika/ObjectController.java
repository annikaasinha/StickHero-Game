package com.example.annika;

import javafx.event.ActionEvent;

public abstract class ObjectController {
    abstract void cherryCountView(ActionEvent event);
    abstract void goToHomePage(ActionEvent event);
}
