package com.example.annika;

public interface PillarInterface {

    void GeneratePillar();

}
